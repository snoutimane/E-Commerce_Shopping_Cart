package com.Product.exception;

public class InvalidProductException extends Exception{
	public InvalidProductException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
