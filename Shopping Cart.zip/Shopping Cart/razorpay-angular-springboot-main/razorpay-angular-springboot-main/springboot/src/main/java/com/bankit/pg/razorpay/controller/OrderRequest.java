package com.bankit.pg.razorpay.controller;

import java.math.BigInteger;

public class OrderRequest {
	
	String fullName;
	String emailId;
	long mobileNumber;
	BigInteger totalAmount;
	
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public long getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public BigInteger getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(BigInteger totalAmount) {
		this.totalAmount = totalAmount;
	}
	

	

}
