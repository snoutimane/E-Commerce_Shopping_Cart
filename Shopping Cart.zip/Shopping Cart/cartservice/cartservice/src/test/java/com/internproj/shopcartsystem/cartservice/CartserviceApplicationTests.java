package com.internproj.shopcartsystem.cartservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CartserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
