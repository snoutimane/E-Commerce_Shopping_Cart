package com.UserManagement.model;

public enum Roles {
	ROLE_CUSTOMER,
	ROLE_ADMIN,
	ROLE_DEALER
}
